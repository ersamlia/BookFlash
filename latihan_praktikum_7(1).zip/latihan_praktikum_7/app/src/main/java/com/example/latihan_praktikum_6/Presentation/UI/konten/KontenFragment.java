package com.example.latihan_praktikum_6.Presentation.UI.konten;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.latihan_praktikum_6.R;
import com.example.latihan_praktikum_6.Presentation.Adapter.DisneyCharacterAdapter;
import com.example.latihan_praktikum_6.Presentation.ViewModel.CharacterViewModel;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;

public class KontenFragment extends Fragment {

    private RecyclerView recyclerView;
    private DisneyCharacterAdapter adapter;
    private CharacterViewModel viewModel;
    private SearchView searchView;

    public KontenFragment() {
        // Diperlukan constructor kosong
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_konten, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewKonten);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new DisneyCharacterAdapter();
        recyclerView.setAdapter(adapter);

        searchView = view.findViewById(R.id.searchViewKonten);

        viewModel = new ViewModelProvider(this).get(CharacterViewModel.class);
        viewModel.getCharacters().observe(getViewLifecycleOwner(), characters -> {
            adapter.setData(characters);
        });

        setupSearch();

        return view;
    }

    private void setupSearch() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                viewModel.searchCharacter(query).observe(getViewLifecycleOwner(), characters -> {
                    adapter.setData(characters);
                });
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                viewModel.searchCharacter(newText).observe(getViewLifecycleOwner(), characters -> {
                    adapter.setData(characters);
                });
                return false;
            }
        });
    }
}
