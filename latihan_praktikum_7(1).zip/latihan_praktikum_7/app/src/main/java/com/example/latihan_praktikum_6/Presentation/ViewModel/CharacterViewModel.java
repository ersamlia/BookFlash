package com.example.latihan_praktikum_6.Presentation.ViewModel;

import android.app.Application;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.latihan_praktikum_6.Data.Database.AppDatabase;
import com.example.latihan_praktikum_6.Data.Entity.DisneyCharacter;
import com.example.latihan_praktikum_6.Data.Remote.ApiService;
import com.example.latihan_praktikum_6.Data.Remote.DisneyApiResponse;
import com.example.latihan_praktikum_6.Data.Remote.RetrofitClient;

import java.util.List;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CharacterViewModel extends AndroidViewModel {
    private LiveData<List<DisneyCharacter>> characters;
    private AppDatabase db;

    public CharacterViewModel(@NonNull Application application) {
        super(application);
        db = AppDatabase.getInstance(application);
        characters = db.disneyCharacterDao().getAll();
        fetchFromApi();
    }

    public LiveData<List<DisneyCharacter>> getCharacters() {
        return characters;
    }

    // Fungsi untuk mencari karakter berdasarkan query
    public LiveData<List<DisneyCharacter>> searchCharacter(String query) {
        return db.disneyCharacterDao().searchByName(query); // Menggunakan query untuk mencari berdasarkan nama
    }

    private void fetchFromApi() {
        ApiService api = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        api.getCharacters().enqueue(new Callback<DisneyApiResponse>() {
            @Override
            public void onResponse(Call<DisneyApiResponse> call, Response<DisneyApiResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Executors.newSingleThreadExecutor().execute(() ->
                            db.disneyCharacterDao().insertAll(response.body().data)
                    );
                }
            }

            @Override
            public void onFailure(Call<DisneyApiResponse> call, Throwable t) {
                Log.e("CharacterViewModel", "API call failed", t);
            }
        });
    }
}
