package com.example.latihan_praktikum_6.Presentation.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.latihan_praktikum_6.Data.Entity.DisneyCharacter;
import com.example.latihan_praktikum_6.R;

//import java.time.Instant;
import java.util.List;

public class DisneyCharacterAdapter extends RecyclerView.Adapter<DisneyCharacterAdapter.ViewHolder> {
    private List<DisneyCharacter> characterList;

    public void setData(List<DisneyCharacter> list) {
        this.characterList = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_character, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DisneyCharacter character = characterList.get(position);
        holder.name.setText(character.name);
        Glide.with(holder.itemView.getContext())
                .load(character.imageUrl)
                .into(holder.image);
    }

    @Override
    public int getItemCount() {
        return characterList != null ? characterList.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        ImageView image;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            image = itemView.findViewById(R.id.ivCharacter);
        }
    }
}

