package com.example.latihan_praktikum_6.Presentation.UI;

import androidx.fragment.app.Fragment;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.latihan_praktikum_6.Presentation.Adapter.DisneyCharacterAdapter;
import com.example.latihan_praktikum_6.Presentation.UI.home.HomeFragment;
import com.example.latihan_praktikum_6.Presentation.UI.konten.KontenFragment;
import com.example.latihan_praktikum_6.Presentation.UI.menu.MenuLainFragment;
import com.example.latihan_praktikum_6.Presentation.UI.setting.SettingFragment;
import com.example.latihan_praktikum_6.Presentation.ViewModel.CharacterViewModel;
import com.example.latihan_praktikum_6.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private DisneyCharacterAdapter adapter;
    private CharacterViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up BottomNavigationView with new listener method
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Use the newer setOnItemSelectedListener
        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment fragment = null;

            // Ganti switch dengan if-else
            if (item.getItemId() == R.id.home) {
                fragment = new HomeFragment();
            } else if (item.getItemId() == R.id.konten) {
                fragment = new KontenFragment();
            } else if (item.getItemId() == R.id.menu_lain) {
                fragment = new MenuLainFragment();
            } else if (item.getItemId() == R.id.setting) {
                fragment = new SettingFragment();
            }

            // Replace the fragment when a menu item is selected
            if (fragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.nav_host_fragment, fragment)
                        .commit();
            }

            return true;
        });

        // Set HomeFragment as default when activity is first created
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, new HomeFragment())
                    .commit();
        }



    }
}
