package com.example.latihan_praktikum_6.Data.Remote;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("character")
    Call<DisneyApiResponse> getCharacters();
}
