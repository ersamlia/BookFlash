package com.example.latihan_praktikum_6.Data.Remote;
import com.example.latihan_praktikum_6.Data.Entity.DisneyCharacter;

import java.util.List;

public class DisneyApiResponse {
    public List<DisneyCharacter> data;
}
