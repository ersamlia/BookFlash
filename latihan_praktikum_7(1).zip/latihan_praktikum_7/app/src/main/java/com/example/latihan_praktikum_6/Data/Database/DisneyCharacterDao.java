package com.example.latihan_praktikum_6.Data.Database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.latihan_praktikum_6.Data.Entity.DisneyCharacter;

import java.util.List;

@Dao
public interface DisneyCharacterDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<DisneyCharacter> characters);

    @Query("SELECT * FROM disney_characters")
    LiveData<List<DisneyCharacter>> getAll();

    // Menambahkan @Query untuk searchByName
    @Query("SELECT * FROM disney_characters WHERE name LIKE :query")
    LiveData<List<DisneyCharacter>> searchByName(String query);
}
