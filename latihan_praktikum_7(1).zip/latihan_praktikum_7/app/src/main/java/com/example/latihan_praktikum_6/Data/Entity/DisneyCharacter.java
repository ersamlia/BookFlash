package com.example.latihan_praktikum_6.Data.Entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.latihan_praktikum_6.Data.Database.Converters;

import java.util.List;

@Entity(tableName = "disney_characters")
@TypeConverters(Converters.class)
public class DisneyCharacter {
    @PrimaryKey
    @NonNull
    public String _id;
    public String name;
    public String imageUrl;
    public List<String> films;
}

