package com.example.latihan_praktikum_6.Presentation.UI.home;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.latihan_praktikum_6.R;
import com.example.latihan_praktikum_6.Presentation.Adapter.DisneyCharacterAdapter;
import com.example.latihan_praktikum_6.Presentation.ViewModel.CharacterViewModel;

import androidx.recyclerview.widget.RecyclerView;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private DisneyCharacterAdapter adapter;
    private CharacterViewModel viewModel;

    public HomeFragment() {
        // Diperlukan constructor kosong
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewHome);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new DisneyCharacterAdapter();
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(CharacterViewModel.class);
        viewModel.getCharacters().observe(getViewLifecycleOwner(), characters -> {
            adapter.setData(characters);
        });

        return view;
    }
}
